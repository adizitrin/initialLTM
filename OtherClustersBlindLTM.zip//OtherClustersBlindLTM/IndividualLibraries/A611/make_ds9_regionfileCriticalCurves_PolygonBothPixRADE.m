function make_ds9_regionfileCriticalCurves_PolygonBothPixRADE
BCG_RA=120.2367277
BCG_DEC=36.05657361
pix_scale=0.065;
load initialLTMmodel.mat
[da_x_dy,da_x_dx]=gradient(alpha_x_ALL);
[da_y_dy,da_y_dx]=gradient(alpha_y_ALL);
poisson_ALL=da_x_dx+da_y_dy;
magnification_ALL_sign=(1./(1-poisson_ALL+da_x_dx.*da_y_dy-da_x_dy.*da_y_dx));

fid = fopen('critical_curves.reg', 'w');
fid2 = fopen('critical_curves_RADEC.reg', 'w');
% print a title, followed by a blank line
fprintf(fid, '# Region file format: DS9 version 4.1\n');
fprintf(fid, 'global color=red dashlist=8 3 width=3 font="helvetica 10 normal roman" select=1 highlite=1 dash=0 fixed=0 edit=1 move=1 delete=1 include=1 source=1\n');
fprintf(fid, 'image\n')

%fill in coordinate
% cc_mask1 = bwperim((magnification_ALL_sign)>0);
% cc_mask2 = bwperim((magnification_ALL_sign)<0); 
% cc_mask = cc_mask1+cc_mask2;
%overlay_cc = imoverlay(log(abs(magnification_ALL_sign)),logical(cc_mask),[1 0 0]);
%figure; imagesc(logical(cc_mask));
% cc_masknew= cc_mask(3:leng-3,3:leng-3);
 close all
 hold on;
boundaries = bwboundaries((magnification_ALL_sign)<0);
numberOfBoundaries = size(boundaries, 1);
for k = 1 : numberOfBoundaries
	thisBoundary = boundaries{k};
	plot(thisBoundary(:,1), thisBoundary(:,2), 'g', 'LineWidth', 2);
    
for p=1:length(thisBoundary(:,2))
    if p==1
          fprintf(fid, 'polygon(%f, %f ', thisBoundary(p,1)+i_x, thisBoundary(p,2)+i_y); 
    else
      fprintf(fid, ',%f, %f ', thisBoundary(p,1)+i_x, thisBoundary(p,2)+i_y);

    end
end
  fprintf(fid, ')\n');
end
hold off;

fclose(fid);
%now rewrite to RADEC
center_of_frame_ra=BCG_RA;
center_of_frame_dec=BCG_DEC;
%BCG stands for conter of frame --> central pixel...
%fid = fopen('critical_curves_RADEC.reg', 'w');
fprintf(fid2, '# Region file format: DS9 version 4.1\n');
fprintf(fid2, 'global color=red dashlist=8 3 width=3 font="helvetica 10 normal roman" select=1 highlite=1 dash=0 fixed=0 edit=1 move=1 delete=1 include=1 source=1\n');
fprintf(fid2, 'fk5\n')
for k = 1 : numberOfBoundaries
	thisBoundary = boundaries{k};
	%plot(thisBoundary(:,2), thisBoundary(:,1), 'g', 'LineWidth', 2);
for i=1:length(thisBoundary(:,1))
centerx=leng/2;
centery=leng/2;
dify_in_pix=thisBoundary(i,2)-centery;
difx_in_pix=-thisBoundary(i,1)+centerx;
dec_offset(i)=dify_in_pix*pix_scale/3600;
ra_offset(i)=difx_in_pix/3600/cosd((center_of_frame_dec+dec_offset(i)))*pix_scale;
    end

for p=1:length(thisBoundary(:,2))
    if p==1
          fprintf(fid2, 'polygon(%.8f, %.8f ', ra_offset(p)+center_of_frame_ra, dec_offset(p)+center_of_frame_dec); 
    else
      fprintf(fid2, ',%.8f, %.8f ',  ra_offset(p)+center_of_frame_ra, dec_offset(p)+center_of_frame_dec);

    end
end
  fprintf(fid2, ')\n');
end
fclose(fid2);